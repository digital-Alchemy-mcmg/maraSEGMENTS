#!/usr/bin/env python3
import sys
import os
import json
import argparse
from src.harness_runner import StageAHarness

def main():
    parser = argparse.ArgumentParser(description="Segment A Standalone Harness: Authoritative Input Ingress & Envelope Sealing (A0–A11)")
    parser.add_argument("--sdna-package", default="samples/sample_sdna_package.json", help="Path to canonical SDNA package JSON")
    parser.add_argument("--compiler-package", default="samples/sample_compiler_package.json", help="Path to Disk/Compiler observation package JSON")
    parser.add_argument("--output", default="./output_stage_a", help="Output directory for sealed handoff deliverables")
    args = parser.parse_args()

    print("=================================================================")
    print(" SEGMENT A: AUTHORITATIVE INGRESS & DETERMINISTIC ENVELOPE (A0–A11)")
    print("=================================================================")

    if not os.path.exists(args.sdna_package):
        print(f"[-] Missing SDNA package file: {args.sdna_package}")
        sys.exit(1)
    if not os.path.exists(args.compiler_package):
        print(f"[-] Missing compiler observation package file: {args.compiler_package}")
        sys.exit(1)

    with open(args.sdna_package, "r") as f:
        sdna_pkg = json.load(f)

    with open(args.compiler_package, "r") as f:
        comp_pkg = json.load(f)

    harness = StageAHarness()

    print("\n[A0–A11] Executing Segment A Sequence...")
    success, res = harness.execute_segment_a(sdna_pkg, comp_pkg)

    if not success:
        print("\n[-] SEGMENT A HALTED (FAIL CLOSED):")
        print(json.dumps(res["failure_receipt"], indent=2))
        print("[-] Downstream execution to Stage B is FORBIDDEN.\n")
        sys.exit(1)

    env = res["envelope"]
    rcpt = res["receipt"]

    print("\n[+] SEGMENT A SEALED SUCCESSFULLY:")
    print(f"    - State:                  SEALED_A")
    print(f"    - Deterministic Env ID:   {env['envelope_id']}")
    print(f"    - SDNA Subject ID:        {env['subject']['sdna_subject_id']}")
    print(f"    - SDNA Manifest Hash:     {env['subject']['sdna_manifest_hash'][:16]}...")
    print(f"    - Compiler Output Hash:   {env['compiler']['compiler_output_hash'][:16]}...")
    print(f"    - Observation Source Hash:{env['observation']['source_hash'][:16]}...")
    print(f"    - Raw Source Isolated:    YES (mutation_allowed=False, interpretation_in_A=False)")
    print(f"    - Gate A Receipt:         PASS (Gate Version {rcpt['gate_version']})")

    paths = harness.export_handoff_package(args.output)
    print(f"\n[+] Deliverables Exported to {args.output}:")
    print(f"    - Sealed Envelope: {paths['envelope_path']}")
    print(f"    - Gate A Receipt:  {paths['receipt_path']}")
    print(f"    - B-Sidecar:       {paths['sidecar_path']}")
    print("\n[SUCCESS] Ready for Stage B Ingress Contract: B_INPUT = SEALED_A_ENVELOPE + A_GATE_RECEIPT + CANDIDATE_SDNA + B_SIDECAR\n")

if __name__ == '__main__':
    main()
