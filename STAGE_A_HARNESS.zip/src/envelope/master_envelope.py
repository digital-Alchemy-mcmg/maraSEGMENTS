from __future__ import annotations

import copy
import hashlib
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple


class EnvelopeBoundaryError(ValueError):
    """Raised when envelope boundary validation fails or required data is missing."""
    pass


class MissingEnvelopeInputError(EnvelopeBoundaryError):
    """Raised when a required envelope field or path is missing."""
    def __init__(self, missing_path: str, stage_name: str, detail: str = ""):
        self.missing_path = missing_path
        self.stage_name = stage_name
        self.detail = detail
        msg = f"[{stage_name}] Missing required envelope path: '{missing_path}'. {detail}".strip()
        super().__init__(msg)


class RunIdentityMismatchError(EnvelopeBoundaryError):
    """Raised when run_id, candidate_id, or target_id does not match the active run."""
    pass


class MasterTravelingEnvelope:
    """Master Traveling Envelope Engine (v2.0).

    The Traveling Envelope is the sole authoritative carrier of run state, target identity,
    source content, provenance, stage outputs, and downstream handoff data.

    Invariants:
    1. Append-only: Prior stage outputs and audit entries are strictly immutable.
    2. Zero sidecar leakage: Raw posting text is NEVER accepted into the envelope.
    3. Fail-closed: Missing fields result in explicit errors, audit logging, and stopped progression.
    4. Continuous identity: run_id, candidate_id, and target_id are strictly verified.
    5. No hidden state or hardcoded fallbacks: All data consumed must originate in the envelope.
    """

    def __init__(
        self,
        candidate_id: str,
        target_id: str,
        run_policy: Optional[Dict[str, Any]] = None,
        pipeline_version: str = "2.0.0-fork",
        run_id: Optional[str] = None,
    ):
        if not candidate_id or not candidate_id.strip():
            raise MissingEnvelopeInputError("Z_state.candidate_id", "INITIALIZATION", "candidate_id cannot be empty.")
        if not target_id or not target_id.strip():
            raise MissingEnvelopeInputError("Z_state.target_id", "INITIALIZATION", "target_id cannot be empty.")

        now = datetime.now(timezone.utc).isoformat()
        self.run_id: str = run_id or f"run-{uuid.uuid4().hex[:12]}"
        self.candidate_id: str = candidate_id.strip()
        self.target_id: str = target_id.strip()
        self.pipeline_version: str = pipeline_version
        self.run_policy: Dict[str, Any] = run_policy or {"max_pages": 1, "strictness": "ABSOLUTE"}
        self.current_stage: str = "INITIALIZED"
        self.status: str = "RUNNING"

        self._A_scout: Optional[Dict[str, Any]] = None
        self._B_sdna: Optional[Dict[str, Any]] = None
        self._C_factory: Dict[str, Any] = {
            "C1_docket": None,
            "C2_claims": None,
            "C3_model": None,
            "C4_layout": None,
            "C5_artifact": None,
        }
        self._audit_trail: List[Dict[str, Any]] = []

        self._record_audit("Z", "RUN_INITIALIZED", {
            "run_id": self.run_id,
            "candidate_id": self.candidate_id,
            "target_id": self.target_id,
            "pipeline_version": self.pipeline_version,
            "created_at": now
        })

    def verify_identity(self, expected_run_id: Optional[str] = None, expected_candidate_id: Optional[str] = None, expected_target_id: Optional[str] = None) -> None:
        """Verifies continuous run identity across stages."""
        if expected_run_id and expected_run_id != self.run_id:
            err = f"Run identity mismatch: Envelope run_id is '{self.run_id}', expected '{expected_run_id}'."
            self._record_audit("VERIFY_IDENTITY", "IDENTITY_MISMATCH", {"error": err})
            raise RunIdentityMismatchError(err)

        if expected_candidate_id and expected_candidate_id != self.candidate_id:
            err = f"Candidate identity mismatch: Envelope candidate_id is '{self.candidate_id}', expected '{expected_candidate_id}'."
            self._record_audit("VERIFY_IDENTITY", "IDENTITY_MISMATCH", {"error": err})
            raise RunIdentityMismatchError(err)

        if expected_target_id and expected_target_id != self.target_id:
            err = f"Target identity mismatch: Envelope target_id is '{self.target_id}', expected '{expected_target_id}'."
            self._record_audit("VERIFY_IDENTITY", "IDENTITY_MISMATCH", {"error": err})
            raise RunIdentityMismatchError(err)

    def validate_boundary(self, target_stage: str) -> None:
        """Mandatory boundary validation before any stage executes. Fails closed."""
        missing = []
        if target_stage in ["B1", "B2", "B3", "B4", "B5"]:
            if not self._A_scout:
                missing.append("A_scout")
            else:
                entity = self._A_scout.get("target_entity", {})
                if not entity.get("company_name"):
                    missing.append("A_scout.target_entity.company_name")
                if not entity.get("job_title"):
                    missing.append("A_scout.target_entity.job_title")
                taxonomy = self._A_scout.get("requirements_taxonomy", {})
                if not taxonomy.get("hard_requirements"):
                    missing.append("A_scout.requirements_taxonomy.hard_requirements")
                if not self._A_scout.get("original_content_sha256"):
                    missing.append("A_scout.original_content_sha256")

        if target_stage in ["B3", "B4", "B5"]:
            if not self._B_sdna or not self._B_sdna.get("competency_tree"):
                missing.append("B_sdna.competency_tree")

        if target_stage in ["B5"]:
            if not self._B_sdna or not self._B_sdna.get("b4_ledger"):
                missing.append("B_sdna.b4_ledger")

        if target_stage.startswith("C"):
            if not self._A_scout:
                missing.append("A_scout")
            if not self._B_sdna:
                missing.append("B_sdna")
            else:
                attestation = self._B_sdna.get("B_sidecar_attestation")
                if not attestation:
                    missing.append("B_sdna.B_sidecar_attestation")
                elif attestation.get("status") != "TERMINATED_AND_VERIFIED":
                    err_msg = f"Sidecar attestation status is '{attestation.get('status')}', expected 'TERMINATED_AND_VERIFIED'."
                    self._record_audit(target_stage, "BOUNDARY_VALIDATION_FAILED", {"error": err_msg})
                    raise EnvelopeBoundaryError(f"[{target_stage}] {err_msg}")

                b4 = self._B_sdna.get("b4_ledger", {})
                if not b4 or not b4.get("admitted_bindings"):
                    missing.append("B_sdna.b4_ledger.admitted_bindings")
                if not b4.get("candidate_identity"):
                    missing.append("B_sdna.b4_ledger.candidate_identity")

                b5 = self._B_sdna.get("b5_projection", {})
                if not b5:
                    missing.append("B_sdna.b5_projection")
                else:
                    if not b5.get("owner_prism"):
                        missing.append("B_sdna.b5_projection.owner_prism")
                    if not b5.get("projection_posture"):
                        missing.append("B_sdna.b5_projection.projection_posture")

        if missing:
            err = f"Missing required envelope paths: {missing}"
            self._record_audit(target_stage, "BOUNDARY_VALIDATION_FAILED", {"missing_paths": missing})
            raise MissingEnvelopeInputError(missing[0], target_stage, f"All missing: {missing}")

    def append_scout(
        self,
        target_entity: Dict[str, Any],
        requirements_taxonomy: Dict[str, Any],
        original_content_sha256: str,
        source_url: str = "",
    ) -> None:
        """Appends Stage A Scout record. Strictly rejects if raw text is mistakenly included."""
        if self._A_scout is not None:
            raise RuntimeError("A_scout is already sealed and cannot be overwritten.")

        # Guard against raw text leakage into the envelope (Checked first!)
        leakage_candidates = ["raw_text", "raw_posting", "raw_job_description_text", "full_description", "raw_html", "posting_body"]
        for key in list(target_entity.keys()) + list(requirements_taxonomy.keys()):
            for leak in leakage_candidates:
                if leak in key.lower():
                    err = f"SECURITY FAULT: Raw target text detected in key '{key}'. Raw text must reside solely in B-Sidecar."
                    self._record_audit("A_SCOUT", "RAW_TEXT_LEAKAGE_REJECTED", {"key": key})
                    raise ValueError(err)

        if not target_entity.get("company_name"):
            raise MissingEnvelopeInputError("target_entity.company_name", "A_SCOUT")
        if not original_content_sha256:
            raise MissingEnvelopeInputError("original_content_sha256", "A_SCOUT")

        self._A_scout = {
            "target_entity": copy.deepcopy(target_entity),
            "requirements_taxonomy": copy.deepcopy(requirements_taxonomy),
            "original_content_sha256": original_content_sha256,
            "source_url": source_url,
        }
        self.current_stage = "A_SCOUT"
        self._record_audit("A_SCOUT", "A_SCOUT_COMMITTED", {
            "company_name": target_entity.get("company_name"),
            "job_title": target_entity.get("job_title"),
            "content_hash": original_content_sha256,
            "hard_req_count": len(requirements_taxonomy.get("hard_requirements", [])),
        })

    def append_b_layer(
        self,
        competency_tree: Dict[str, Any],
        b4_ledger: Dict[str, Any],
        b5_projection: Dict[str, Any],
        b_sidecar_attestation: Dict[str, Any],
    ) -> None:
        """Appends complete sealed Stage B layer with mandatory destruction tombstone."""
        if self._B_sdna is not None:
            raise RuntimeError("B_sdna is already sealed and cannot be overwritten.")

        # Fail-closed validation
        if not b_sidecar_attestation or b_sidecar_attestation.get("status") != "TERMINATED_AND_VERIFIED":
            err = "B_sidecar_attestation missing or status is not 'TERMINATED_AND_VERIFIED'."
            self._record_audit("B5", "SIDECAR_DESTRUCTION_VERIFICATION_FAILED", {"error": err})
            raise EnvelopeBoundaryError(err)

        if not competency_tree:
            raise MissingEnvelopeInputError("B_sdna.competency_tree", "B_STAGE")
        if not b4_ledger:
            raise MissingEnvelopeInputError("B_sdna.b4_ledger", "B_STAGE")
        if not b5_projection:
            raise MissingEnvelopeInputError("B_sdna.b5_projection", "B_STAGE")

        self._B_sdna = {
            "competency_tree": copy.deepcopy(competency_tree),
            "b4_ledger": copy.deepcopy(b4_ledger),
            "b5_projection": copy.deepcopy(b5_projection),
            "B_sidecar_attestation": copy.deepcopy(b_sidecar_attestation),
        }
        self.current_stage = "B5_COMPLETE"
        self.status = "complete:STOP_BEFORE_RESUME_FACTORY"
        self._record_audit("B5", "B_CYCLE_COMPLETE_AND_SIDECAR_DESTROYED", {
            "sidecar_id": b_sidecar_attestation.get("sidecar_id"),
            "owner_prism": b5_projection.get("owner_prism"),
        })

    def verify_c1_handoff_readiness(self) -> Tuple[bool, List[str]]:
        """Validates that envelope is completely ready for C1 ingestion with zero leaks."""
        errors: List[str] = []

        if not self._A_scout:
            errors.append("A_scout is missing.")
        if not self._B_sdna:
            errors.append("B_sdna is missing.")
        else:
            attestation = self._B_sdna.get("B_sidecar_attestation")
            if not attestation:
                errors.append("B_sidecar_attestation is missing from B_sdna.")
            elif attestation.get("status") != "TERMINATED_AND_VERIFIED":
                errors.append(f"Sidecar was not terminated cleanly: status is '{attestation.get('status')}'.")

            proj = self._B_sdna.get("b5_projection")
            if not proj or not proj.get("prism_intro_evaluation") or not proj.get("projection_posture"):
                errors.append("B5 projection is missing required fields (prism_intro_evaluation or projection_posture).")

        return len(errors) == 0, errors

    def append_c_stage(self, stage_name: str, payload: Dict[str, Any]) -> None:
        """Appends output from C1, C2, C3, C4, or C5."""
        if stage_name not in self._C_factory:
            raise KeyError(f"Invalid C stage: {stage_name}. Must be one of {list(self._C_factory.keys())}")
        if self._C_factory[stage_name] is not None:
            raise RuntimeError(f"{stage_name} already has a committed payload and cannot be overwritten.")

        self._C_factory[stage_name] = copy.deepcopy(payload)
        self.current_stage = stage_name
        self._record_audit(stage_name, f"{stage_name}_COMMITTED", {"keys": list(payload.keys())})

    def _record_audit(self, stage: str, event: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        self._audit_trail.append({
            "stage": stage,
            "event": event,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "metadata": metadata or {},
        })

    def to_dict(self) -> Dict[str, Any]:
        return {
            "envelope_version": "2.0.0",
            "Z_state": {
                "run_id": self.run_id,
                "candidate_id": self.candidate_id,
                "target_id": self.target_id,
                "pipeline_version": self.pipeline_version,
                "current_stage": self.current_stage,
                "status": self.status,
                "run_policy": copy.deepcopy(self.run_policy),
            },
            "A_scout": copy.deepcopy(self._A_scout),
            "B_sdna": copy.deepcopy(self._B_sdna),
            "C_factory": copy.deepcopy(self._C_factory),
            "audit_trail": copy.deepcopy(self._audit_trail),
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
