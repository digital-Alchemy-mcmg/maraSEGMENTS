import os
import json
import copy
from typing import Dict, Any, Tuple, Optional
from .scout import SegmentAEngine, SegmentAState, TypedSegmentAError

class StageAHarness:
    """Self-contained runner for Segment A (A0 through A11).
    
    RULE: A does not interpret the résumé, job, or SDNA.
    It establishes trustworthy inputs, preserves their provenance, binds required
    references, and emits the authoritative A-envelope.
    """
    
    def __init__(self):
        self.engine = SegmentAEngine()
        self.sealed_envelope: Optional[Dict[str, Any]] = None
        self.gate_a_receipt: Optional[Dict[str, Any]] = None
        self.failure_receipt: Optional[Dict[str, Any]] = None

    def execute_segment_a(
        self,
        sdna_package: Optional[Dict[str, Any]],
        compiler_package: Optional[Dict[str, Any]]
    ) -> Tuple[bool, Dict[str, Any]]:
        """Executes complete Segment A flow (A0 through A11) with error-trapping."""
        success, result = self.engine.execute(sdna_package, compiler_package)
        if success:
            self.sealed_envelope = result["envelope"]
            self.gate_a_receipt = result["receipt"]
            self.failure_receipt = None
            return True, {
                "status": "SEALED_A",
                "envelope": self.sealed_envelope,
                "receipt": self.gate_a_receipt
            }
        else:
            self.sealed_envelope = None
            self.gate_a_receipt = None
            self.failure_receipt = result.get("failure_receipt", {})
            return False, {
                "status": "HALTED_A",
                "failure_receipt": self.failure_receipt
            }

    def export_handoff_package(self, output_dir: str = "./output_stage_a") -> Dict[str, str]:
        if not self.sealed_envelope or not self.gate_a_receipt:
            raise RuntimeError("Cannot export handoff: Segment A did not seal successfully (HALTED_A).")
            
        os.makedirs(output_dir, exist_ok=True)
        env_path = os.path.join(output_dir, "sealed_a_envelope.json")
        receipt_path = os.path.join(output_dir, "gate_a_receipt.json")
        sidecar_path = os.path.join(output_dir, "stage_a_sidecar.json")
        
        with open(env_path, "w") as f:
            json.dump(self.sealed_envelope, f, indent=2)

        with open(receipt_path, "w") as f:
            json.dump(self.gate_a_receipt, f, indent=2)

        sidecar_dict = {
            "sidecar_id": f"sc-b-{self.sealed_envelope['envelope_id'].replace('ENV-A-', '')}",
            "raw_posting": self.sealed_envelope["isolated_source"]["source_text"],
            "original_content_sha256": self.sealed_envelope["isolated_source"]["source_hash"],
            "source_url": self.sealed_envelope["observation"]["source_url"],
            "status": "INITIALIZED_READY_FOR_STAGE_B",
            "run_binding": {
                "envelope_id": self.sealed_envelope["envelope_id"],
                "target_id": self.sealed_envelope["observation"]["observation_id"],
                "candidate_id": self.sealed_envelope["subject"]["sdna_subject_id"]
            }
        }
        with open(sidecar_path, "w") as f:
            json.dump(sidecar_dict, f, indent=2)

        return {
            "envelope_path": env_path,
            "receipt_path": receipt_path,
            "sidecar_path": sidecar_path
        }
