import copy
import hashlib
import json
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any, List, Tuple, Optional

SEGMENT_A_SCHEMA_VERSION = "2.0.0"

@dataclass(frozen=True)
class SegmentAContract:
    """A0 - Bootstrap the Segment A contract.
    Before accepting data, A knows exactly what it is allowed to receive.
    """
    REQUIRED_SDNA_FIELDS = [
        "sdna_manifest",
        "sdna_subject_id",
        "sdna_version",
        "sdna_source_hash",
        "prominence_reference",
        "source_evidence_references"
    ]

    REQUIRED_OBSERVATION_FIELDS = [
        "id",
        "company",
        "title",
        "location",
        "source_url",
        "original_content_sha256",
        "raw_job_description_text"
    ]

    OPTIONAL_OBSERVATION_FIELDS = [
        "employment_type",
        "compensation",
        "application_status",
        "vendor"
    ]

    REQUIRED_COMPILER_FIELDS = [
        "compiler_receipt",
        "compiler_schema_version",
        "compiler_output_hash",
        "source_hash",
        "observation"
    ]

    FORBIDDEN_ACTIONS = [
        "inferred_qualifications",
        "inferred_candidate_fit",
        "invented_missing_values",
        "reconstructed_source_data",
        "b_stage_bindings",
        "c_stage_projections"
    ]


class SegmentAState(str, Enum):
    AWAITING_INPUT = "AWAITING_INPUT"
    SDNA_LOADED = "SDNA_LOADED"
    SDNA_VERIFIED = "SDNA_VERIFIED"
    TARGET_LOADED = "TARGET_LOADED"
    COMPILER_VERIFIED = "COMPILER_VERIFIED"
    OBSERVATION_VERIFIED = "OBSERVATION_VERIFIED"
    ENVELOPE_BUILT = "ENVELOPE_BUILT"
    GATE_A_PASS = "GATE_A_PASS"
    SEALED_A = "SEALED_A"
    HALTED_A = "HALTED_A"


class TypedSegmentAError(ValueError):
    def __init__(self, stage: str, missing_or_fault: str, detail: str = ""):
        self.stage = stage
        self.missing_or_fault = missing_or_fault
        self.detail = detail
        msg = f"[{stage}] Fail-Closed: '{missing_or_fault}'. {detail}".strip()
        super().__init__(msg)


class TypedMissingInputError(TypedSegmentAError):
    pass


class CompilerProvenanceError(TypedSegmentAError):
    pass


class SDNAVerificationError(TypedSegmentAError):
    pass


class EnvelopeInvariantError(TypedSegmentAError):
    pass


def deterministic_envelope_id(
    schema_version: str,
    sdna_manifest_hash: str,
    compiler_output_hash: str,
    observation_source_hash: str
) -> str:
    seed = f"{schema_version}:{sdna_manifest_hash}:{compiler_output_hash}:{observation_source_hash}"
    h = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return f"ENV-A-{h[:16]}"


class SegmentAEngine:
    """Segment A: Ingress, Provenance, and Deterministic Envelope Construction (A0–A11).
    RULE: A does not interpret the résumé, job, or SDNA.
    """

    def __init__(self):
        self.state: SegmentAState = SegmentAState.AWAITING_INPUT
        self.contract = SegmentAContract()
        self.raw_sdna_package: Optional[Dict[str, Any]] = None
        self.verified_sdna_ref: Optional[Dict[str, Any]] = None
        self.raw_compiler_package: Optional[Dict[str, Any]] = None
        self.verified_compiler_ref: Optional[Dict[str, Any]] = None
        self.verified_observation: Optional[Dict[str, Any]] = None
        self.isolated_source: Optional[Dict[str, Any]] = None
        self.binding_ref: Optional[Dict[str, Any]] = None
        self.envelope: Optional[Dict[str, Any]] = None
        self.gate_a_receipt: Optional[Dict[str, Any]] = None
        self.halt_error: Optional[TypedSegmentAError] = None

    def execute(self, sdna_package: Optional[Dict[str, Any]], compiler_package: Optional[Dict[str, Any]]) -> Tuple[bool, Dict[str, Any]]:
        self.state = SegmentAState.AWAITING_INPUT
        self.halt_error = None

        try:
            _ = self.contract

            # A1: Accept SDNA first
            self.state = SegmentAState.SDNA_LOADED
            self.raw_sdna_package = self._ingest_sdna(sdna_package)

            # A2: Verify SDNA package
            self.state = SegmentAState.SDNA_VERIFIED
            self.verified_sdna_ref = self._verify_sdna(self.raw_sdna_package)

            # A3: Accept Disk/Compiler observation
            self.state = SegmentAState.TARGET_LOADED
            self.raw_compiler_package = self._ingest_observation(compiler_package)

            # A4: Verify compiler receipt + source provenance
            self.state = SegmentAState.COMPILER_VERIFIED
            self.verified_compiler_ref = self._verify_compiler_output(self.raw_compiler_package)

            # A5: Validate target observation
            self.state = SegmentAState.OBSERVATION_VERIFIED
            observation_data = self.raw_compiler_package["observation"]
            self.verified_observation = self._validate_observation(observation_data)

            # A6: Isolate authoritative raw source
            self.isolated_source = self._isolate_raw_source(self.verified_observation["raw_job_description_text"])

            # A7: Bind SDNA references to observation
            self.binding_ref = self._bind_references_only(self.verified_sdna_ref, self.verified_observation)

            # A8: Construct traveling envelope
            self.state = SegmentAState.ENVELOPE_BUILT
            self.envelope = self._construct_a_envelope(
                self.verified_sdna_ref,
                self.verified_compiler_ref,
                self.verified_observation,
                self.isolated_source,
                self.binding_ref
            )

            # A9: Verify envelope invariants
            self.state = SegmentAState.GATE_A_PASS
            invariant_results = self._verify_envelope_invariants(self.envelope)

            # A10 & A11: Seal Segment A and emit receipt
            self.envelope["status"] = "SEALED_A"
            self.state = SegmentAState.SEALED_A
            self.gate_a_receipt = self._seal_and_emit(self.envelope, invariant_results)

            return True, {
                "envelope": self.envelope,
                "receipt": self.gate_a_receipt
            }

        except TypedSegmentAError as e:
            self.state = SegmentAState.HALTED_A
            self.halt_error = e
            failure_receipt = {
                "stage": "A",
                "current_substage": e.stage,
                "result": "FAIL",
                "error": str(e),
                "fault": e.missing_or_fault,
                "detail": e.detail,
                "reconstruction_permitted": False,
                "downstream_execution_permitted": False
            }
            return False, {"failure_receipt": failure_receipt}
        except Exception as e:
            self.state = SegmentAState.HALTED_A
            typed_e = TypedSegmentAError("A_PIPELINE", "UNEXPECTED_EXCEPTION", str(e))
            self.halt_error = typed_e
            failure_receipt = {
                "stage": "A",
                "current_substage": "UNHANDLED",
                "result": "FAIL",
                "error": str(e),
                "reconstruction_permitted": False,
                "downstream_execution_permitted": False
            }
            return False, {"failure_receipt": failure_receipt}

    def _ingest_sdna(self, sdna_package: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not sdna_package:
            raise TypedMissingInputError(
                stage="A0_SDNA_BOOT",
                missing_or_fault="sdnaPackage",
                detail="SDNA canonical package is completely missing. A fails closed."
            )
        return copy.deepcopy(sdna_package)

    def _verify_sdna(self, sdna: Dict[str, Any]) -> Dict[str, Any]:
        for field in SegmentAContract.REQUIRED_SDNA_FIELDS:
            if field not in sdna or sdna[field] is None:
                raise TypedMissingInputError("A2_VERIFY_SDNA", field, f"Required SDNA field '{field}' is missing.")

        manifest = sdna.get("sdna_manifest")
        if not manifest or not isinstance(manifest, dict):
            raise SDNAVerificationError("A2_VERIFY_SDNA", "sdna_manifest", "Manifest must be a non-empty mapping.")

        declared_hash = sdna.get("sdna_source_hash")
        computed_hash = hashlib.sha256(json.dumps(manifest, sort_keys=True).encode("utf-8")).hexdigest()
        manifest_signed_hash = manifest.get("integrity", {}).get("content_sha256")

        if declared_hash != computed_hash and declared_hash != manifest_signed_hash:
            raise SDNAVerificationError("A2_VERIFY_SDNA", "sdna_source_hash", "SDNA manifest hash does not match computed.")

        prom_ref = sdna.get("prominence_reference")
        if not prom_ref or not str(prom_ref).strip():
            raise SDNAVerificationError("A2_VERIFY_SDNA", "prominence_reference", "Prominence reference is empty.")

        return {
            "sdna_subject_id": sdna["sdna_subject_id"],
            "sdna_version": sdna["sdna_version"],
            "sdna_manifest_hash": declared_hash,
            "prominence_reference": prom_ref,
            "source_evidence_references": copy.deepcopy(sdna["source_evidence_references"])
        }

    def _ingest_observation(self, compiler_package: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        if not compiler_package:
            raise TypedMissingInputError("A3_INGEST_OBSERVATION", "compilerPackage", "Compiler observation package missing.")

        for f in SegmentAContract.REQUIRED_COMPILER_FIELDS:
            if f not in compiler_package or compiler_package[f] is None:
                raise TypedMissingInputError("A3_INGEST_OBSERVATION", f, f"Required compiler field '{f}' is missing.")

        return copy.deepcopy(compiler_package)

    def _verify_compiler_output(self, comp: Dict[str, Any]) -> Dict[str, Any]:
        obs = comp.get("observation", {})
        obs_serialized = json.dumps(obs, sort_keys=True).encode("utf-8")
        calc_hash = hashlib.sha256(obs_serialized).hexdigest()

        declared_output_hash = comp.get("compiler_output_hash")
        if calc_hash != declared_output_hash:
            raise CompilerProvenanceError(
                "A4_VERIFY_COMPILER",
                "compiler_output_hash",
                f"Calculated hash '{calc_hash}' != declared '{declared_output_hash}'."
            )

        receipt = comp.get("compiler_receipt", {})
        if receipt.get("output_hash") != declared_output_hash:
            raise CompilerProvenanceError(
                "A4_VERIFY_COMPILER",
                "compiler_receipt.output_hash",
                "Compiler receipt does not reference declared output hash."
            )

        src_hash = comp.get("source_hash")
        obs_src_hash = obs.get("original_content_sha256")
        if src_hash != obs_src_hash:
            raise CompilerProvenanceError(
                "A4_VERIFY_COMPILER",
                "source_hash",
                f"Source hash '{src_hash}' does not match observation original_content_sha256 '{obs_src_hash}'."
            )

        raw_text = obs.get("raw_job_description_text", "")
        recomputed_text_hash = hashlib.sha256(raw_text.encode("utf-8")).hexdigest()
        if recomputed_text_hash != obs_src_hash:
            raise CompilerProvenanceError(
                "A4_VERIFY_COMPILER",
                "raw_job_description_text",
                f"Recomputed raw text hash '{recomputed_text_hash}' != original_content_sha256 '{obs_src_hash}'."
            )

        return {
            "compiler_schema_version": comp["compiler_schema_version"],
            "compiler_output_hash": declared_output_hash,
            "compiler_receipt": copy.deepcopy(receipt)
        }

    def _validate_observation(self, obs: Dict[str, Any]) -> Dict[str, Any]:
        for field in SegmentAContract.REQUIRED_OBSERVATION_FIELDS:
            if field not in obs or not str(obs[field]).strip():
                raise TypedMissingInputError("A5_VALIDATE_OBSERVATION", field, f"Observation field '{field}' is required.")

        validated = {
            "id": obs["id"].strip(),
            "company": obs["company"].strip(),
            "title": obs["title"].strip(),
            "location": obs["location"].strip(),
            "source_url": obs["source_url"].strip(),
            "original_content_sha256": obs["original_content_sha256"].strip(),
            "raw_job_description_text": obs["raw_job_description_text"]
        }

        for opt in SegmentAContract.OPTIONAL_OBSERVATION_FIELDS:
            val = obs.get(opt)
            validated[opt] = val if (val is not None and str(val).strip()) else "ABSENT"

        return validated

    def _isolate_raw_source(self, raw_text: str) -> Dict[str, Any]:
        text_hash = hashlib.sha256(raw_text.encode("utf-8")).hexdigest()
        return {
            "source_hash": text_hash,
            "source_text": raw_text,
            "classification": "SOURCE",
            "mutation_allowed": False,
            "interpretation_allowed_in_A": False
        }

    def _bind_references_only(self, sdna_ref: Dict[str, Any], obs_ref: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "subject_ref": sdna_ref["sdna_subject_id"],
            "manifest_hash_ref": sdna_ref["sdna_manifest_hash"],
            "observation_ref": obs_ref["id"],
            "source_hash_ref": obs_ref["original_content_sha256"],
            "semantic_relationships_asserted": False
        }

    def _construct_a_envelope(
        self,
        sdna_ref: Dict[str, Any],
        comp_ref: Dict[str, Any],
        obs: Dict[str, Any],
        isolated_src: Dict[str, Any],
        binding: Dict[str, Any]
    ) -> Dict[str, Any]:
        env_id = deterministic_envelope_id(
            SEGMENT_A_SCHEMA_VERSION,
            sdna_ref["sdna_manifest_hash"],
            comp_ref["compiler_output_hash"],
            obs["original_content_sha256"]
        )

        return {
            "envelope_schema": "TRAVELING_ENVELOPE_A",
            "envelope_version": SEGMENT_A_SCHEMA_VERSION,
            "envelope_id": env_id,
            "stage": "A",
            "status": "UNSEALED",
            "subject": copy.deepcopy(sdna_ref),
            "observation": {
                "observation_id": obs["id"],
                "target_entity": {
                    "company": obs["company"],
                    "title": obs["title"],
                    "location": obs["location"],
                    "employment_type": obs["employment_type"],
                    "compensation": obs["compensation"],
                    "application_status": obs["application_status"],
                    "vendor": obs["vendor"]
                },
                "source_url": obs["source_url"],
                "source_hash": obs["original_content_sha256"]
            },
            "compiler": copy.deepcopy(comp_ref),
            "isolated_source": copy.deepcopy(isolated_src),
            "reference_binding": copy.deepcopy(binding),
            "provenance_chain": [
                {
                    "receipt_type": "SDNA_CANONICAL_RECEIPT",
                    "subject_id": sdna_ref["sdna_subject_id"],
                    "hash": sdna_ref["sdna_manifest_hash"]
                },
                {
                    "receipt_type": "COMPILER_RECEIPT",
                    "compiler_schema": comp_ref["compiler_schema_version"],
                    "hash": comp_ref["compiler_output_hash"]
                },
                {
                    "receipt_type": "OBSERVATION_RECEIPT",
                    "observation_id": obs["id"],
                    "hash": obs["original_content_sha256"]
                }
            ],
            "downstream": {
                "B_status": "NOT_EXECUTED",
                "C_status": "NOT_EXECUTED"
            }
        }

    def _verify_envelope_invariants(self, envelope: Dict[str, Any]) -> Dict[str, bool]:
        checks = {}
        checks["subject_exists"] = bool(envelope.get("subject"))
        checks["observation_exists"] = bool(envelope.get("observation"))
        checks["compiler_exists"] = bool(envelope.get("compiler"))
        checks["isolated_source_exists"] = bool(envelope.get("isolated_source"))

        checks["sdna_manifest_hash_verified"] = bool(envelope["subject"].get("sdna_manifest_hash"))
        checks["compiler_output_hash_verified"] = bool(envelope["compiler"].get("compiler_output_hash"))
        checks["observation_source_hash_verified"] = (
            envelope["observation"].get("source_hash") == envelope["isolated_source"].get("source_hash")
        )
        checks["isolated_source_mutation_forbidden"] = not envelope["isolated_source"].get("mutation_allowed", True)

        checks["no_b_stage_fields"] = (envelope.get("downstream", {}).get("B_status") == "NOT_EXECUTED" and "B_sdna" not in envelope)
        checks["no_c_stage_fields"] = (envelope.get("downstream", {}).get("C_status") == "NOT_EXECUTED" and "C_factory" not in envelope)
        checks["provenance_chain_complete"] = len(envelope.get("provenance_chain", [])) == 3

        for check_name, passed in checks.items():
            if not passed:
                raise EnvelopeInvariantError("A9_VERIFY_INVARIANTS", check_name, "Envelope invariant assertion failed.")

        return checks

    def _seal_and_emit(self, envelope: Dict[str, Any], invariant_results: Dict[str, bool]) -> Dict[str, Any]:
        return {
            "stage": "A",
            "result": "PASS",
            "envelope_id": envelope["envelope_id"],
            "sdna_manifest_hash": envelope["subject"]["sdna_manifest_hash"],
            "compiler_output_hash": envelope["compiler"]["compiler_output_hash"],
            "observation_source_hash": envelope["observation"]["source_hash"],
            "gate_version": SEGMENT_A_SCHEMA_VERSION,
            "invariant_results": invariant_results
        }
