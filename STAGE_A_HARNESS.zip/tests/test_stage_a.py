import unittest
import os
import json
import copy
from src.harness_runner import StageAHarness
from src.scout import (
    SegmentAState,
    TypedMissingInputError,
    CompilerProvenanceError,
    SDNAVerificationError,
    EnvelopeInvariantError,
    deterministic_envelope_id
)

class TestSegmentAHarness(unittest.TestCase):
    def setUp(self):
        with open("samples/sample_sdna_package.json") as f:
            self.sdna_pkg = json.load(f)
        with open("samples/sample_compiler_package.json") as f:
            self.comp_pkg = json.load(f)
        self.harness = StageAHarness()

    def test_a0_through_a11_happy_path(self):
        success, res = self.harness.execute_segment_a(self.sdna_pkg, self.comp_pkg)
        self.assertTrue(success)
        self.assertEqual(res["status"], "SEALED_A")

        env = res["envelope"]
        rcpt = res["receipt"]

        expected_id = deterministic_envelope_id(
            "2.0.0",
            self.sdna_pkg["sdna_source_hash"],
            self.comp_pkg["compiler_output_hash"],
            self.comp_pkg["source_hash"]
        )
        self.assertEqual(env["envelope_id"], expected_id)

        h2 = StageAHarness()
        _, res2 = h2.execute_segment_a(self.sdna_pkg, self.comp_pkg)
        self.assertEqual(res2["envelope"]["envelope_id"], expected_id)

        self.assertEqual(env["isolated_source"]["classification"], "SOURCE")
        self.assertFalse(env["isolated_source"]["mutation_allowed"])
        self.assertFalse(env["isolated_source"]["interpretation_allowed_in_A"])

        self.assertEqual(env["downstream"]["B_status"], "NOT_EXECUTED")
        self.assertEqual(env["downstream"]["C_status"], "NOT_EXECUTED")
        self.assertNotIn("B_sdna", env)
        self.assertNotIn("C_factory", env)

        self.assertEqual(rcpt["result"], "PASS")
        self.assertTrue(rcpt["invariant_results"]["provenance_chain_complete"])

        paths = self.harness.export_handoff_package("./test_output_a")
        self.assertTrue(os.path.exists(paths["envelope_path"]))
        self.assertTrue(os.path.exists(paths["receipt_path"]))
        self.assertTrue(os.path.exists(paths["sidecar_path"]))

    def test_a1_fail_closed_missing_sdna(self):
        success, res = self.harness.execute_segment_a(None, self.comp_pkg)
        self.assertFalse(success)
        self.assertEqual(res["status"], "HALTED_A")
        self.assertEqual(self.harness.engine.state, SegmentAState.HALTED_A)
        self.assertEqual(res["failure_receipt"]["current_substage"], "A0_SDNA_BOOT")
        self.assertFalse(res["failure_receipt"]["downstream_execution_permitted"])

    def test_a4_fail_closed_compiler_hash_tampering(self):
        bad_comp = copy.deepcopy(self.comp_pkg)
        bad_comp["observation"]["title"] = "Tampered Job Title"

        success, res = self.harness.execute_segment_a(self.sdna_pkg, bad_comp)
        self.assertFalse(success)
        self.assertEqual(res["status"], "HALTED_A")
        self.assertEqual(res["failure_receipt"]["current_substage"], "A4_VERIFY_COMPILER")
        self.assertFalse(res["failure_receipt"]["reconstruction_permitted"])

    def test_a4_fail_closed_raw_text_hash_tampering(self):
        bad_comp = copy.deepcopy(self.comp_pkg)
        bad_comp["observation"]["raw_job_description_text"] = "Completely altered raw text"
        import hashlib
        bad_comp["compiler_output_hash"] = hashlib.sha256(json.dumps(bad_comp["observation"], sort_keys=True).encode()).hexdigest()
        bad_comp["compiler_receipt"]["output_hash"] = bad_comp["compiler_output_hash"]

        success, res = self.harness.execute_segment_a(self.sdna_pkg, bad_comp)
        self.assertFalse(success)
        self.assertEqual(res["status"], "HALTED_A")
        self.assertEqual(res["failure_receipt"]["current_substage"], "A4_VERIFY_COMPILER")

    def test_a5_optional_fields_marked_absent_never_inferred(self):
        comp = copy.deepcopy(self.comp_pkg)
        obs = comp["observation"]
        del obs["employment_type"]
        del obs["compensation"]
        del obs["application_status"]
        del obs["vendor"]

        import hashlib
        comp["compiler_output_hash"] = hashlib.sha256(json.dumps(obs, sort_keys=True).encode()).hexdigest()
        comp["compiler_receipt"]["output_hash"] = comp["compiler_output_hash"]

        success, res = self.harness.execute_segment_a(self.sdna_pkg, comp)
        self.assertTrue(success)
        env = res["envelope"]
        target_entity = env["observation"]["target_entity"]
        self.assertEqual(target_entity["employment_type"], "ABSENT")
        self.assertEqual(target_entity["compensation"], "ABSENT")
        self.assertEqual(target_entity["application_status"], "ABSENT")
        self.assertEqual(target_entity["vendor"], "ABSENT")

if __name__ == '__main__':
    unittest.main()
