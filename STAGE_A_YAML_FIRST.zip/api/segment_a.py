import json
from http.server import BaseHTTPRequestHandler
from src.harness_runner import StageAHarness


def execute_payload(payload):
    if not isinstance(payload, dict):
        raise ValueError("Request body must be a JSON object.")
    return StageAHarness().execute_segment_a(payload.get("sdna_yaml"), payload.get("compiler_package"))


class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
            ok, result = execute_payload(payload)
            status = 200 if ok else 422
        except Exception as exc:
            status = 400
            result = {"status": "HALTED_A", "failure_receipt": {"stage": "A", "current_substage": "INGRESS_HTTP", "result": "FAIL", "error": str(exc), "reconstruction_permitted": False, "downstream_execution_permitted": False}}
        raw = json.dumps(result, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
