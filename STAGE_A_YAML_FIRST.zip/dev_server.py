#!/usr/bin/env python3
import json
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from api.segment_a import execute_payload


class Handler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.path = "/index.html"
        return super().do_GET()

    def do_POST(self):
        if self.path != "/api/segment_a":
            self.send_error(404)
            return
        try:
            n = int(self.headers.get("Content-Length", "0"))
            payload = json.loads(self.rfile.read(n).decode("utf-8"))
            ok, result = execute_payload(payload)
            status = 200 if ok else 422
        except Exception as exc:
            status = 400
            result = {"status": "HALTED_A", "failure_receipt": {"stage": "A", "current_substage": "INGRESS_HTTP", "result": "FAIL", "error": str(exc), "reconstruction_permitted": False, "downstream_execution_permitted": False}}
        raw = json.dumps(result, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


if __name__ == "__main__":
    print("Segment A YAML-first test surface: http://0.0.0.0:8000")
    ThreadingHTTPServer(("0.0.0.0", 8000), Handler).serve_forever()
