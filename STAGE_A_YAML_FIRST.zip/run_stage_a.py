#!/usr/bin/env python3
import argparse
import json
import sys
from src.harness_runner import StageAHarness


def main():
    parser = argparse.ArgumentParser(description="Segment A A0-A11 YAML-first execution harness")
    parser.add_argument("--sdna-file", required=True, help="Canonical SDNA .yaml/.yml file")
    parser.add_argument("--compiler-package", required=True, help="Compiler/target package JSON file")
    args = parser.parse_args()
    if not args.sdna_file.lower().endswith((".yaml", ".yml")):
        print("INPUT ERROR: --sdna-file must be .yaml or .yml")
        sys.exit(2)
    try:
        with open(args.sdna_file, "r", encoding="utf-8") as f:
            sdna_yaml = f.read()
        with open(args.compiler_package, "r", encoding="utf-8") as f:
            compiler_package = json.load(f)
    except Exception as exc:
        print(f"INPUT ERROR: {exc}")
        sys.exit(2)
    ok, result = StageAHarness().execute_segment_a(sdna_yaml, compiler_package)
    print(json.dumps(result, indent=2))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
