"""Segment A standalone runtime."""
