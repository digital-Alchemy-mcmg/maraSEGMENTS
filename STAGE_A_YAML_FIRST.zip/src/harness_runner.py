from typing import Any, Dict, Tuple
from src.scout import SegmentAEngine


class StageAHarness:
    def __init__(self):
        self.engine = SegmentAEngine()

    def execute_segment_a(self, sdna_yaml: str, compiler_package: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        return self.engine.execute(sdna_yaml, compiler_package)
