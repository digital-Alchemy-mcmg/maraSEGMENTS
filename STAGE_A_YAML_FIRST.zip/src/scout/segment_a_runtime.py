from __future__ import annotations

import copy
import hashlib
import json
from enum import Enum
from typing import Any, Dict, Optional, Tuple

from src.sdna import SDNAIngressError, validate_sdna_yaml


class SegmentAState(str, Enum):
    AWAITING_SDNA = "AWAITING_SDNA"
    SDNA_VERIFIED = "SDNA_VERIFIED"
    AWAITING_TARGET = "AWAITING_TARGET"
    SEALED_A = "SEALED_A"
    HALTED_A = "HALTED_A"


class SegmentAError(RuntimeError):
    def __init__(self, substage: str, message: str):
        super().__init__(message)
        self.substage = substage


def canonical_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def deterministic_envelope_id(schema_version: str, sdna_hash: str, compiler_hash: str, source_hash: str) -> str:
    material = f"{schema_version}{sdna_hash}{compiler_hash}{source_hash}".encode("utf-8")
    return "ENV-A-" + hashlib.sha256(material).hexdigest()[:16]


class SegmentAEngine:
    REQUIRED_TARGET_FIELDS = ("id", "company", "title", "location", "source_url", "original_content_sha256", "raw_job_description_text")
    OPTIONAL_TARGET_FIELDS = ("employment_type", "compensation", "application_status", "vendor")

    def __init__(self):
        self.state = SegmentAState.AWAITING_SDNA
        self._verified_sdna: Optional[Dict[str, Any]] = None

    def _failure(self, substage: str, exc: Exception) -> Tuple[bool, Dict[str, Any]]:
        self.state = SegmentAState.HALTED_A
        return False, {
            "status": "HALTED_A",
            "failure_receipt": {
                "stage": "A",
                "current_substage": substage,
                "result": "FAIL",
                "error_type": exc.__class__.__name__,
                "error": str(exc),
                "reconstruction_permitted": False,
                "downstream_execution_permitted": False,
            },
        }

    def execute(self, sdna_yaml: str, compiler_package: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        try:
            # A0 — contract bootstrap
            contract = {
                "stage": "A",
                "sequence": [f"A{i}" for i in range(12)],
                "forbidden_operations": ["candidate_fit_interpretation", "sdna_rescoring", "resume_writing", "layout_selection"],
            }

            # A1 — accept canonical SDNA YAML
            try:
                verified_sdna = validate_sdna_yaml(sdna_yaml)
            except SDNAIngressError as exc:
                return self._failure("A1_ACCEPT_SDNA", exc)
            self._verified_sdna = copy.deepcopy(verified_sdna)

            # A2 — verify SDNA manifest deterministically
            recomputed_manifest_hash = canonical_hash(verified_sdna["sdna_manifest"])
            if recomputed_manifest_hash != verified_sdna["sdna_manifest_hash"]:
                raise SegmentAError("A2_VERIFY_SDNA", "SDNA manifest hash mismatch.")
            self.state = SegmentAState.SDNA_VERIFIED

            # A3 — accept compiler package only after A2
            if not isinstance(compiler_package, dict):
                raise SegmentAError("A3_ACCEPT_COMPILER", "Compiler/target package must be a JSON object.")
            self.state = SegmentAState.AWAITING_TARGET

            # A4 — verify compiler receipt and raw source provenance
            observation = compiler_package.get("observation")
            receipt = compiler_package.get("compiler_receipt")
            compiler_hash = compiler_package.get("compiler_output_hash")
            source_hash = compiler_package.get("source_hash")
            if not isinstance(observation, dict) or not isinstance(receipt, dict) or not compiler_hash or not source_hash:
                raise SegmentAError("A4_VERIFY_COMPILER", "Compiler package is missing observation, compiler_receipt, compiler_output_hash, or source_hash.")
            recomputed_compiler_hash = canonical_hash(observation)
            if recomputed_compiler_hash != compiler_hash or receipt.get("output_hash") != compiler_hash:
                raise SegmentAError("A4_VERIFY_COMPILER", "Compiler output hash verification failed.")
            raw_text = observation.get("raw_job_description_text")
            if not isinstance(raw_text, str) or raw_text == "":
                raise SegmentAError("A4_VERIFY_COMPILER", "raw_job_description_text is required for provenance verification.")
            recomputed_source_hash = hashlib.sha256(raw_text.encode("utf-8")).hexdigest()
            if not (source_hash == observation.get("original_content_sha256") == recomputed_source_hash):
                raise SegmentAError("A4_VERIFY_COMPILER", "Source hash chain verification failed.")

            # A5 — validate target observation; optional absence is explicit and never inferred
            for field in self.REQUIRED_TARGET_FIELDS:
                if observation.get(field) in (None, ""):
                    raise SegmentAError("A5_VALIDATE_TARGET", f"Required observation field missing: {field}")
            normalized_observation = copy.deepcopy(observation)
            for field in self.OPTIONAL_TARGET_FIELDS:
                if normalized_observation.get(field) in (None, ""):
                    normalized_observation[field] = "ABSENT"

            # A6 — isolate authoritative raw source
            isolated_source = {
                "classification": "SOURCE",
                "source_sha256": source_hash,
                "source_url": normalized_observation["source_url"],
                "raw_job_description_text": raw_text,
                "mutation_allowed": False,
                "interpretation_allowed_in_A": False,
            }

            # A7 — reference-only binding; no semantic relationship is asserted
            subject_observation_binding = {
                "subject_ref": verified_sdna["sdna_subject_id"],
                "observation_ref": normalized_observation["id"],
                "relationship_asserted": False,
                "prominence_reference": verified_sdna["prominence_reference"],
                "prominence_reference_state": verified_sdna["prominence_reference_state"],
            }

            # A8 — deterministic envelope identity
            envelope_id = deterministic_envelope_id(
                verified_sdna["sdna_version"],
                verified_sdna["sdna_manifest_hash"],
                compiler_hash,
                source_hash,
            )
            envelope = {
                "envelope_id": envelope_id,
                "schema_version": "A-1.0",
                "subject": {
                    "sdna_subject_id": verified_sdna["sdna_subject_id"],
                    "sdna_version": verified_sdna["sdna_version"],
                    "sdna_manifest_hash": verified_sdna["sdna_manifest_hash"],
                    "sdna_raw_content_sha256": verified_sdna["sdna_raw_content_sha256"],
                    "atom_count": verified_sdna["atom_count"],
                    "prominence_reference": verified_sdna["prominence_reference"],
                    "prominence_reference_state": verified_sdna["prominence_reference_state"],
                },
                "compiler": {
                    "compiler_schema_version": compiler_package.get("compiler_schema_version"),
                    "compiler_output_hash": compiler_hash,
                },
                "observation": {
                    "observation_identity": normalized_observation["id"],
                    "source_hash": source_hash,
                    "target_entity": {
                        "employer": normalized_observation["company"],
                        "job_title": normalized_observation["title"],
                        "location": normalized_observation["location"],
                        "employment_type": normalized_observation["employment_type"],
                        "compensation": normalized_observation["compensation"],
                        "application_status": normalized_observation["application_status"],
                        "vendor": normalized_observation["vendor"],
                    },
                },
                "isolated_source": isolated_source,
                "reference_binding": subject_observation_binding,
                "downstream": {"B_status": "NOT_EXECUTED", "C_status": "NOT_EXECUTED"},
            }

            # A9 — invariants
            if envelope["downstream"] != {"B_status": "NOT_EXECUTED", "C_status": "NOT_EXECUTED"}:
                raise SegmentAError("A9_VERIFY_INVARIANTS", "Downstream stage fields were populated inside Segment A.")
            if subject_observation_binding["relationship_asserted"] is not False:
                raise SegmentAError("A9_VERIFY_INVARIANTS", "Segment A asserted a semantic candidate/target relationship.")

            # A10 — seal
            self.state = SegmentAState.SEALED_A

            # A11 — receipt and B handoff contract
            gate_receipt = {
                "stage": "A",
                "result": "PASS",
                "state": "SEALED_A",
                "envelope_id": envelope_id,
                "sdna_manifest_hash": verified_sdna["sdna_manifest_hash"],
                "sdna_raw_content_sha256": verified_sdna["sdna_raw_content_sha256"],
                "compiler_output_hash": compiler_hash,
                "source_hash": source_hash,
                "sdna_validation_gates": verified_sdna["validation_gates"],
                "invariant_results": {
                    "sdna_verified_before_target": True,
                    "provenance_chain_complete": True,
                    "zero_semantic_fit_interpretation": True,
                    "zero_prominence_fabrication": verified_sdna["prominence_reference"] is None,
                    "downstream_not_executed": True,
                },
                "downstream_execution_permitted": True,
            }
            return True, {
                "status": "SEALED_A",
                "contract": contract,
                "envelope": envelope,
                "receipt": gate_receipt,
                "candidate_sdna": verified_sdna,
                "b_intake_contract": ["SEALED_A_ENVELOPE", "GATE_A_RECEIPT", "CANDIDATE_SDNA", "B_SIDECAR"],
            }
        except SegmentAError as exc:
            return self._failure(exc.substage, exc)
        except Exception as exc:
            return self._failure("A_RUNTIME", exc)
