from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List

import yaml


class SDNAIngressError(ValueError):
    def __init__(self, gate: str, message: str):
        super().__init__(message)
        self.gate = gate


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _require(condition: bool, gate: str, message: str) -> None:
    if not condition:
        raise SDNAIngressError(gate, message)


def validate_sdna_yaml(raw_yaml: str) -> Dict[str, Any]:
    """Validate canonical operator-supplied SDNA YAML without interpreting candidate evidence."""
    _require(isinstance(raw_yaml, str) and raw_yaml.strip() != "", "SDNA_G01_SOURCE", "SDNA YAML input is required.")
    try:
        document = yaml.safe_load(raw_yaml)
    except yaml.YAMLError as exc:
        raise SDNAIngressError("SDNA_G02_PARSE", f"Invalid SDNA YAML: {exc}") from exc

    _require(isinstance(document, dict), "SDNA_G03_ROOT", "SDNA root must be a mapping.")
    schema_version = document.get("schema_version")
    _require(isinstance(schema_version, str) and schema_version.strip() != "", "SDNA_G04_SCHEMA", "schema_version is required.")

    candidate = document.get("candidate")
    _require(isinstance(candidate, dict), "SDNA_G05_CANDIDATE", "candidate mapping is required.")
    candidate_id = candidate.get("candidate_id")
    _require(isinstance(candidate_id, str) and candidate_id.strip() != "", "SDNA_G06_IDENTITY", "candidate.candidate_id is required.")

    ontology = candidate.get("governing_ontology")
    _require(isinstance(ontology, list) and len(ontology) > 0, "SDNA_G07_ONTOLOGY", "candidate.governing_ontology must be a non-empty list.")

    source_registry = candidate.get("source_registry")
    _require(isinstance(source_registry, dict) and len(source_registry) > 0, "SDNA_G08_SOURCES", "candidate.source_registry must be a non-empty mapping.")

    spatial = candidate.get("spatial_dna")
    _require(isinstance(spatial, dict), "SDNA_G09_SPATIAL", "candidate.spatial_dna mapping is required.")
    atoms = spatial.get("evidence_atoms")
    _require(isinstance(atoms, list) and len(atoms) > 0, "SDNA_G10_ATOMS", "candidate.spatial_dna.evidence_atoms must be a non-empty list.")

    atom_ids: List[str] = []
    evidence_refs: List[str] = []
    for idx, atom in enumerate(atoms):
        _require(isinstance(atom, dict), "SDNA_G10_ATOMS", f"evidence_atoms[{idx}] must be a mapping.")
        atom_id = atom.get("atom_id")
        _require(isinstance(atom_id, str) and atom_id.strip() != "", "SDNA_G10_ATOMS", f"evidence_atoms[{idx}].atom_id is required.")
        _require(atom_id not in atom_ids, "SDNA_G10_ATOMS", f"Duplicate atom_id: {atom_id}")
        atom_ids.append(atom_id)
        refs = atom.get("evidence_sources")
        _require(isinstance(refs, list) and len(refs) > 0, "SDNA_G10_ATOMS", f"{atom_id} requires evidence_sources.")
        for ref in refs:
            _require(isinstance(ref, str) and ref in source_registry, "SDNA_G10_ATOMS", f"{atom_id} references unknown source: {ref}")
            evidence_refs.append(ref)
        _require(isinstance(atom.get("state"), str) and atom.get("state"), "SDNA_G10_ATOMS", f"{atom_id} requires state.")
        _require(isinstance(atom.get("semantic_ceiling"), str) and atom.get("semantic_ceiling"), "SDNA_G10_ATOMS", f"{atom_id} requires semantic_ceiling.")
        _require(isinstance(atom.get("resume_admissibility"), str) and atom.get("resume_admissibility"), "SDNA_G10_ATOMS", f"{atom_id} requires resume_admissibility.")

    manifest_hash = _canonical_hash(document)
    raw_hash = hashlib.sha256(raw_yaml.encode("utf-8")).hexdigest()
    prominence_reference = candidate.get("prominence_reference")

    return {
        "sdna_manifest": document,
        "sdna_subject_id": candidate_id,
        "sdna_version": schema_version,
        "sdna_manifest_hash": manifest_hash,
        "sdna_raw_content_sha256": raw_hash,
        "prominence_reference": prominence_reference if isinstance(prominence_reference, str) and prominence_reference.strip() else None,
        "prominence_reference_state": "PRESENT" if isinstance(prominence_reference, str) and prominence_reference.strip() else "ABSENT_IN_CANONICAL_SDNA",
        "source_evidence_references": sorted(set(evidence_refs)),
        "atom_count": len(atoms),
        "validation_gates": [
            "SDNA_G01_SOURCE", "SDNA_G02_PARSE", "SDNA_G03_ROOT", "SDNA_G04_SCHEMA", "SDNA_G05_CANDIDATE",
            "SDNA_G06_IDENTITY", "SDNA_G07_ONTOLOGY", "SDNA_G08_SOURCES", "SDNA_G09_SPATIAL", "SDNA_G10_ATOMS",
        ],
    }
