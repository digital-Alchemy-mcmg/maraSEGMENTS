import copy
import hashlib
import json
import pathlib
import unittest

from src.harness_runner import StageAHarness
from src.scout.segment_a_runtime import canonical_hash, deterministic_envelope_id

ROOT = pathlib.Path(__file__).parent


def load_sdna():
    return (ROOT / "fixtures" / "minimal_sdna.yaml").read_text(encoding="utf-8")


def compiler_package():
    raw = "Test-only authoritative target posting."
    source_hash = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    observation = {
        "id": "OBS-TEST-001", "company": "Test Company", "title": "Test Role", "location": "Test Location",
        "source_url": "https://example.invalid/test", "original_content_sha256": source_hash,
        "raw_job_description_text": raw, "employment_type": "Full-Time", "compensation": "ABSENT",
        "application_status": "UNAPPLIED", "vendor": "TEST-ONLY",
    }
    output_hash = canonical_hash(observation)
    return {"compiler_receipt": {"output_hash": output_hash}, "compiler_schema_version": "TEST-1.0", "compiler_output_hash": output_hash, "source_hash": source_hash, "observation": observation}


class SegmentAYamlIngressTests(unittest.TestCase):
    def test_yaml_first_happy_path_and_determinism(self):
        sdna = load_sdna(); comp = compiler_package()
        ok, result = StageAHarness().execute_segment_a(sdna, comp)
        self.assertTrue(ok); self.assertEqual(result["status"], "SEALED_A")
        subject = result["envelope"]["subject"]
        expected = deterministic_envelope_id(subject["sdna_version"], subject["sdna_manifest_hash"], comp["compiler_output_hash"], comp["source_hash"])
        self.assertEqual(result["envelope"]["envelope_id"], expected)
        ok2, result2 = StageAHarness().execute_segment_a(sdna, comp)
        self.assertTrue(ok2); self.assertEqual(result2["envelope"]["envelope_id"], expected)

    def test_missing_sdna_halts_before_target(self):
        ok, result = StageAHarness().execute_segment_a("", compiler_package())
        self.assertFalse(ok); self.assertEqual(result["failure_receipt"]["current_substage"], "A1_ACCEPT_SDNA")
        self.assertFalse(result["failure_receipt"]["downstream_execution_permitted"])

    def test_malformed_yaml_halts(self):
        ok, result = StageAHarness().execute_segment_a("candidate: [", compiler_package())
        self.assertFalse(ok); self.assertEqual(result["failure_receipt"]["current_substage"], "A1_ACCEPT_SDNA")

    def test_compiler_hash_tamper_halts(self):
        comp = compiler_package(); comp["observation"]["title"] = "Tampered"
        ok, result = StageAHarness().execute_segment_a(load_sdna(), comp)
        self.assertFalse(ok); self.assertEqual(result["failure_receipt"]["current_substage"], "A4_VERIFY_COMPILER")

    def test_raw_source_hash_tamper_halts(self):
        comp = compiler_package(); comp["observation"]["raw_job_description_text"] = "Altered"
        comp["compiler_output_hash"] = canonical_hash(comp["observation"]); comp["compiler_receipt"]["output_hash"] = comp["compiler_output_hash"]
        ok, result = StageAHarness().execute_segment_a(load_sdna(), comp)
        self.assertFalse(ok); self.assertEqual(result["failure_receipt"]["current_substage"], "A4_VERIFY_COMPILER")

    def test_optional_fields_absent_and_prominence_not_fabricated(self):
        comp = compiler_package()
        for key in ("employment_type", "compensation", "application_status", "vendor"):
            del comp["observation"][key]
        comp["compiler_output_hash"] = canonical_hash(comp["observation"]); comp["compiler_receipt"]["output_hash"] = comp["compiler_output_hash"]
        ok, result = StageAHarness().execute_segment_a(load_sdna(), comp)
        self.assertTrue(ok)
        target = result["envelope"]["observation"]["target_entity"]
        self.assertTrue(all(target[k] == "ABSENT" for k in ("employment_type", "compensation", "application_status", "vendor")))
        self.assertIsNone(result["envelope"]["subject"]["prominence_reference"])
        self.assertEqual(result["envelope"]["subject"]["prominence_reference_state"], "ABSENT_IN_CANONICAL_SDNA")
        self.assertTrue(result["receipt"]["invariant_results"]["zero_prominence_fabrication"])


if __name__ == "__main__": unittest.main()
